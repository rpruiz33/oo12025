package modelo;

public interface ICocinero {
	String cocinar();
}
