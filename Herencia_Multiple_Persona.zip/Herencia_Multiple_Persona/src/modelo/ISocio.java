package modelo;

public interface ISocio {
	String pagarCuota();
}
